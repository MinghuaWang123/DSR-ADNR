%% TEST 
clear all;
close all;
clc;


load Sandiego_new
load Sandiego_gt
data=hsi;
mask=hsi_gt;

f_show=data(:,:,[37,18,8]);
for i=1:3
    max_f=max(max(f_show(:,:,i)));
    min_f=min(min(f_show(:,:,i)));
    f_show(:,:,i)=(f_show(:,:,i)-min_f)/(max_f-min_f);
end
DataTest=data;

[H,W,Dim]=size(DataTest);
num=H*W;
for i=1:Dim
    DataTest(:,:,i) = (DataTest(:,:,i)-min(min(DataTest(:,:,i)))) / (max(max(DataTest(:,:,i))-min(min(DataTest(:,:,i)))));
end
nSig = 10/255;
noiselevel = nSig*ones(1,Dim);      % for case 1

% Gaussian noise
for i =1:Dim
     oriData3_noise(:,:,i)=DataTest(:,:,i)  + noiselevel(i)*randn(H,W);
%        mixed(vv,:)=addnoise(mixed(vv,:),'mg',ratio);
end

for i = 1:Dim
     oriData3_noise(:,:,i)=imnoise(oriData3_noise(:,:,i),'salt & pepper',0.01);

end


[PSNR_noise,SSIM_noise,~,~] = evaluate(DataTest,oriData3_noise,H,W);
mPSNR_noise = mean(PSNR_noise);mSSIM_noise = mean(SSIM_noise);
%%%%
mask_reshape = reshape(mask, 1, num);
anomaly_map = logical(double(mask_reshape)>0);                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           
normal_map = logical(double(mask_reshape)==0);
Y=reshape(oriData3_noise, num, Dim)';


%% Patch-based Iteration Parameters
Par.nSig        =   nSig;                               % Variance of the noise image
Par.SearchWin   =   30;                                 % Non-local patch searching window
Par.c1          =   8*sqrt(2);                           % Constant num for HSI
Par.step        =   4;   

Par.patsize     =   5;
Par.patnum      =   200;      
Par.Iter        =   5;
Par.lamada      =   0.3;

Par.mu          =   0.001;
Par.lamdaS      =   0.0002;
Par.k_subspace  =   5;
Par.K_dict      =   10;
Par.Pat         =   20;
Par.beta        =   0.3;
display         =   0;

tic;
[X,S]= NGmeet_AD_DeNoising( oriData3_noise, DataTest, Par,display );
Time_DSRAD = toc;
[PSNR,SSIM,~,~] = evaluate(DataTest,X,H,W);
mPSNR= mean(PSNR);mSSIM = mean(SSIM);


r_new_DSR=sqrt(sum(S.^2,1));
r_max = max(r_new_DSR(:));
taus = linspace(0, r_max, 5000);
PF_DSR=zeros(1,5000);
PD_DSR=zeros(1,5000);
    
for index2 = 1:length(taus)
    tau = taus(index2);
    anomaly_map_rx = (r_new_DSR> tau);
    PF_DSR(index2) = sum(anomaly_map_rx & normal_map)/sum(normal_map);
    PD_DSR(index2) = sum(anomaly_map_rx & anomaly_map)/sum(anomaly_map);
end
area_DSR = sum((PF_DSR(1:end-1)-PF_DSR(2:end)).*(PD_DSR(2:end)+PD_DSR(1:end-1))/2);

area_DSR_final = sum((PF_DSR(1:end-1)-PF_DSR(2:end)).*(PD_DSR(2:end)+PD_DSR(1:end-1))/2);