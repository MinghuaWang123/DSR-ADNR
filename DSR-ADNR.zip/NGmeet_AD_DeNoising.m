function [E_Img_out,S]= NGmeet_AD_DeNoising( oriData3_noise, DataTest, Par,display )

tic;
tol2= 1e-2;
tol1= 1e-6;
mu_max=1e10;

E_Img            = oriData3_noise;                                                         % Estimated Image
[Height, Width, Band]  = size(E_Img);  
N = Height*Width;
TotalPatNum      = (Height-Par.patsize+1)*(Width-Par.patsize+1);         % Total Patch Number in the image
Average          = mean(oriData3_noise,3);                      % Calculate the average band for fast spatial non-local searching
[Neighbor_arr, Num_arr, Self_arr] =	NeighborIndex(Average, Par);   

%% initialization
Y      = reshape(E_Img, N, Band)';
[E,~,~]= svd(Y,'econ');
E      = E(:,1:Par.k_subspace);   

X      = reshape((E'*Y)', Height,Width, Par.k_subspace);
X_matrix = E'*Y;


Dict   = ConstructionD_w(X_matrix,Par.K_dict,Par.Pat); 
DtX  = Dict'*X_matrix;
DtD  = Dict'*Dict;
ita1 = 1.0/((norm(Dict,2))^2);
numDict = size(Dict,2);
L     = zeros(numDict,N);
S     = zeros(Par.k_subspace,N);
X_F    = norm(E'*Y,'fro');
% if display
%     disp(['initial,rank=' num2str(rank(L))]);
% end
Lam1  = S;
Lam2  = zeros(Height, Width, Par.k_subspace);
for iter = 1 : Par.Iter 

%% update W
Temp_w = X + Lam2/Par.mu;
  
N_Img1 = reshape((E'*reshape(oriData3_noise, N, Band)')', Height,Width, Par.k_subspace); %%% add change N_Img1 as oriData3_noise 


% %non-local patch grouping and noise estimation
    Average             =   mean(Temp_w,3);
    [CurPat, Mat, Sigma_arr]	=	Cub2Patch( Temp_w, N_Img1, Average, Par );

    if (mod(iter-1,2)==0)
        Par.patnum = Par.patnum - 10;                                          % Lower Noise level, less NL patches
        NL_mat  =  Block_matching(Mat, Par, Neighbor_arr, Num_arr, Self_arr);  % Caculate Non-local similar patches for each
        if(iter==1)
            Sigma_arr = Par.nSig * ones(size(Sigma_arr))*sqrt(Par.k_subspace/Band);                      % First Iteration use the input noise parameter
        end
    end

% non-local low-rank denoising
    [Spa_EPat, Spa_W]    =  NLPatEstimation( NL_mat, Self_arr, Sigma_arr, CurPat, Par); 
% reconstruct patches to 3-D image
    [Spa_Img, Spa_Wei]   =  Patch2Cub( Spa_EPat, Spa_W, Par.patsize, Height, Width, Par.k_subspace );       % Patch to Cubic
    W = Spa_Img./Spa_Wei;

 
 %% update X
     Temp_X1 = reshape((E'*Y)',Height,Width, Par.k_subspace);
     Temp_X3 = reshape(Par.mu * ( Dict*L + S ) - Lam1,Height,Width, Par.k_subspace);
     
     Temp_X  = Temp_X1 + Par.mu * W -Lam2 + Temp_X3;
     X1       = Temp_X/( 1 + 2 * Par.mu);
     X_matrix = (reshape(X1,Height*Width, Par.k_subspace))';
     
     E_Img = reshape(reshape(X1, Height*Width, Par.k_subspace)*E',Height,Width, Band);
%  %% update D   
     DtX  = Dict'*X_matrix;

 %% update L
    Temp_L      = L+ita1*DtX-ita1*DtD*L-ita1*Dict'*S+ita1*Dict'*Lam1/Par.mu;
    L1          = svd_threshold(Temp_L,Par.beta*ita1/Par.mu);
 
  %% update S
  
    Temp_S = X_matrix-Dict*L1+Lam1/Par.mu;
    S1     = solve_l1l2(Temp_S,Par.lamdaS/Par.mu);

%% update E 
    Y      = reshape(E_Img, N, Band)';
   [E,~,~] = svd(Y,'econ');
    E      = E(:,1:Par.k_subspace);
%% updata Lam1 Lam2
    RES    = X_matrix-Dict*L1-S1;
    Lam1   = Lam1 + Par.mu*(RES);
    Lam2   = Lam2 + Par.mu*(X1-W);
    
   ktt2(iter)    = Par.mu*max(max(sqrt(1/ita1)*norm(L1-L,'fro'),norm(reshape(X1-X,N, Par.k_subspace),'fro')),norm(S1-S,'fro'))/X_F;
   if ktt2(iter)<tol2
       rou=1.1;
   else
       rou=1;
   end
   Par.mu=min(mu_max,rou*Par.mu);
   
   S=S1;
   L=L1;
   X=X1;
   noise_kkt(iter) = norm((E'*Y)-X_matrix, 'fro' )/X_F;
   ktt1(iter)=norm(RES,'fro')/X_F;
   if display
        disp(['iter ' num2str(iter) ',mu=' num2str(Par.mu,'%2.1e') ...
            ',rank=' num2str(rank(L,1e-3*norm(L,2))) ',stopC1=' num2str(ktt1,'%2.3e') ',stopC2=' num2str(ktt2,'%2.3e')]);
    end
   if(ktt1(iter)<tol1 && ktt2(iter)<tol2)
       break;
   end
   

    E_Img_out = E_Img;
    if iter<Par.Iter
    E_Img = 0.1*oriData3_noise+0.9*E_Img;

    else
    end
    

end

 end
function Y=svd_threshold(X,r)
[U,S,V] = svd(X, 'econ'); % stable 
 sigma = diag(S);
 svp = length(find(sigma>r));
    if svp>=1
        sigma = sigma(1:svp)-r;
    else
        svp = 1;
        sigma = 0;
    end
    Y = U(:,1:svp)*diag(sigma)*V(:,1:svp)';
end
